import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    model_name = 'rover.urdf'  # Replace with your actual URDF file name
    robot_description_content = PathJoinSubstitution([
        FindPackageShare("robot_description"), "urdf", model_name
    ])

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description_content
        }]
    )

    fake_odom_publisher_node = Node(
        package='robot_description',
        executable='fake_odom_publisher',
        output='screen'
    )

    rviz_config_path = PathJoinSubstitution([
        FindPackageShare("robot_description"), "rviz", "rover_config.rviz"
    ])

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config_path],
        output='screen'
    )

    return LaunchDescription([
        robot_state_publisher_node,
        fake_odom_publisher_node,
        rviz_node,
    ])

