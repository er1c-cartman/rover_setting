#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <chrono>

using namespace std::chrono_literals;

class FakeOdomPublisher : public rclcpp::Node
{
public:
    FakeOdomPublisher()
    : Node("fake_odom_publisher"), x_(0.0), y_(0.0), theta_(0.0)
    {
        odom_publisher_ = this->create_publisher<nav_msgs::msg::Odometry>("odom", 10);
        tf_broadcaster_ = std::make_shared<tf2_ros::TransformBroadcaster>(this);

        timer_ = this->create_wall_timer(
            100ms, std::bind(&FakeOdomPublisher::publish_odometry, this));
    }

private:
    void publish_odometry()
    {
        // Update the robot's position (simple simulation)
        double delta_x = 0.0;
        double delta_theta = 0.0;

        x_ += delta_x;
        theta_ += delta_theta;

        // Create quaternion from yaw
        tf2::Quaternion quat;
        quat.setRPY(0, 0, theta_);
        geometry_msgs::msg::Quaternion odom_quat = tf2::toMsg(quat);

        // Publish odometry message
        nav_msgs::msg::Odometry odom_msg;
        odom_msg.header.stamp = this->get_clock()->now();
        odom_msg.header.frame_id = "odom";
        odom_msg.child_frame_id = "base_link";

        odom_msg.pose.pose.position.x = x_;
        odom_msg.pose.pose.position.y = y_;
        odom_msg.pose.pose.position.z = 0.197; // Set z position to base_link height from ground
        odom_msg.pose.pose.orientation = odom_quat;

        odom_msg.twist.twist.linear.x = delta_x;
        odom_msg.twist.twist.angular.z = delta_theta;

        odom_publisher_->publish(odom_msg);

        // Publish the transform over tf
        geometry_msgs::msg::TransformStamped odom_trans;
        odom_trans.header.stamp = odom_msg.header.stamp;
        odom_trans.header.frame_id = "odom";
        odom_trans.child_frame_id = "base_link";

        odom_trans.transform.translation.x = x_;
        odom_trans.transform.translation.y = y_;
        odom_trans.transform.translation.z = 0.197; // Set z position to base_link height from ground
        odom_trans.transform.rotation = odom_quat;

        tf_broadcaster_->sendTransform(odom_trans);
    }

    rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_publisher_;
    std::shared_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
    rclcpp::TimerBase::SharedPtr timer_;

    double x_, y_, theta_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<FakeOdomPublisher>());
    rclcpp::shutdown();
    return 0;
}

